# ACKnet
A platform that connects students and teachers 


## ACKnet Live Classroom

ACKnet now uses LiveKit for its embedded live classroom. Jitsi is no longer used by the Sessions component.

### Setup

1. Create a LiveKit Cloud project.
2. Copy the values into `.env.local`:

```env
LIVEKIT_URL=wss://YOUR-PROJECT.livekit.cloud
LIVEKIT_API_KEY=your-livekit-api-key
LIVEKIT_API_SECRET=your-livekit-api-secret
```

Never expose `LIVEKIT_API_SECRET` to the browser or prefix it with `NEXT_PUBLIC_`.

3. Install dependencies:

```bash
npm install
```

4. Start the app:

```bash
npm run dev
```

The existing Live Sessions page creates a unique room name for each session. Teachers can go live and students can join from inside ACKnet.
