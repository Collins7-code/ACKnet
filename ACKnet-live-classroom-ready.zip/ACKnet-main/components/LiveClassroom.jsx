"use client";

import { useEffect, useState } from "react";
import { LiveKitRoom, VideoConference } from "@livekit/components-react";
import "@livekit/components-styles";
import { X } from "lucide-react";
import { supabase } from "../lib/supabaseClient";
import { COLORS, SANS } from "../lib/constants";

export default function LiveClassroom({ roomName, displayName, title, onClose }) {
  const [token, setToken] = useState(null);
  const [serverUrl, setServerUrl] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function join() {
      try {
        const { data } = await supabase.auth.getSession();
        const accessToken = data.session?.access_token;
        if (!accessToken) throw new Error("Your login session has expired. Please sign in again.");

        const response = await fetch(
          `/api/livekit/token?room=${encodeURIComponent(roomName)}&username=${encodeURIComponent(displayName || "ACKnet User")}`,
          { headers: { Authorization: `Bearer ${accessToken}` } }
        );
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || "Unable to join classroom");
        if (!cancelled) {
          setToken(result.token);
          setServerUrl(result.url);
        }
      } catch (err) {
        if (!cancelled) setError(err.message || "Unable to join classroom");
      }
    }

    join();
    return () => { cancelled = true; };
  }, [roomName, displayName]);

  if (error) {
    return (
      <div style={{ position: "fixed", inset: 0, zIndex: 1000, background: "#05070b", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
        <div style={{ maxWidth: 420, textAlign: "center", color: "#fff", fontFamily: SANS }}>
          <h2 style={{ margin: "0 0 10px", fontSize: 20 }}>Could not join ACKnet Classroom</h2>
          <p style={{ color: "#aeb7c5", lineHeight: 1.5 }}>{error}</p>
          <button onClick={onClose} style={{ marginTop: 10, border: 0, borderRadius: 8, padding: "10px 16px", cursor: "pointer" }}>Go back</button>
        </div>
      </div>
    );
  }

  if (!token || !serverUrl) {
    return (
      <div style={{ position: "fixed", inset: 0, zIndex: 1000, background: "#05070b", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: SANS }}>
        Connecting to ACKnet Classroom…
      </div>
    );
  }

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 1000, background: "#05070b", color: "#fff" }}>
      <LiveKitRoom token={token} serverUrl={serverUrl} connect audio video style={{ height: "100%" }} data-lk-theme="default">
        <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
          <header style={{ height: 58, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 14px", background: COLORS.navy, fontFamily: SANS }}>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>ACKnet Classroom</div>
              <div style={{ fontSize: 11, color: "#b9c3d2", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{title}</div>
            </div>
            <button onClick={onClose} aria-label="Leave classroom" style={{ display: "flex", alignItems: "center", gap: 6, border: 0, borderRadius: 7, padding: "8px 11px", background: "#b42318", color: "#fff", cursor: "pointer" }}>
              <X size={15} /> Leave
            </button>
          </header>
          <div style={{ flex: 1, minHeight: 0 }}>
            <VideoConference />
          </div>
        </div>
      </LiveKitRoom>
    </div>
  );
}
